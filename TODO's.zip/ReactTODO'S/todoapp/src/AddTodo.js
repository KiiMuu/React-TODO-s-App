import React, { Component } from 'react';

class AddTodo extends Component {
    state = {
        content: ''
    }
    handleChange = (e) => {
        this.setState({
            content: e.target.value
        })
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.addTodo(this.state);
        this.setState({
            content: ''
        })
    }
    render() {
        return(
            <form onSubmit={this.handleSubmit}>
                <div className="form-group">
                    <label>Add new TODO's:</label>
                    <input type="text" className="form-control" onChange={this.handleChange} value={this.state.content} />
                </div>
            </form>
        );
    }
}

export default AddTodo;
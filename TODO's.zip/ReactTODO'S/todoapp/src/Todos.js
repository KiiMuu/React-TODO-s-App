import React from 'react';
import './Todos.css';

const Todos = ({todos, deleteTodo}) => {
    const todoList = todos.length ? (
        todos.map(todo => {
            return(
                <div className="list-group-item" key={todo.id}>
                    <span onClick={() => {deleteTodo(todo.id)}}>{todo.content}</span>
                </div>
            )
        })
    ) : (
        <p className="list-group-item text-center no-todos">You have no TODO's left!</p>
    )
    return(
        <div className="todos list-group">
            {todoList}
        </div>
    );
}

export default Todos;